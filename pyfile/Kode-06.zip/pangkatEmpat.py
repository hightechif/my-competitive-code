# pangkatEmpat.py : Program Python yang membangkitkan tabel
#                   pangkat 4 dari bilangan bulat 1 hingga 10.
# Agus Arif, 05-10-2015

# Definisi fungsi yang menghitung pangkat 4
def pangkat4(bil):
  hasil = bil * bil * bil * bil
  return hasil

# Bagian utama dari program
print 'Tabel Pangkat Empat'
print '-------------------\n'

for i in range(1, 11):
  print '  %2d^4 = %5d' % (i, pangkat4(i))

print '\nSelesai.'
