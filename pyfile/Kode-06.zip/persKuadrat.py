# persKuadrat.py: Program Python yang memanfaatkan fungsi-
#                 fungsi pendukung untuk menentukan dua akar
#                 persamaan kuadrat secara berulang-kali.
# Agus Arif, 05-10-2015

# Tampilkan judul program
def judul():
  print ' Penentuan Akar Persamaan Kuadrat'
  print 'Dengan Diketahui Tiga Koefisiennya'
  print '~' * 34

# Hitung diskriminan
def nilaiDiskriminan(A, B, C):
  D = B ** 2 - 4 * A * C
  return D

# Hitung 2 akar real dan berbeda
def akarBerbeda(A, B, D):
  x1 = (-B + D**0.5) / (2 * A)
  x2 = (-B - D**0.5) / (2 * A)
  return x1, x2

# Hitung 2 akar real yang kembar
def akarKembar(A, B):
  x1 = -B / (2 * A)
  x2 = x1
  return x1, x2

# Hitung 2 akar yang kompleks
def akarKompleks(A, B, D):
  bgnReal = -B / (2 * A)
  bgnImajiner = 1j * (abs(D)**0.5) / (2 * A) 
  x1 = bgnReal + bgnImajiner
  x2 = bgnReal - bgnImajiner
  return x1, x2

########## Bagian utama program ###############

judul()

# Ulangi kalang penentuan akar persamaan kuadrat
jawab = 'Y'                   # pemberian nilai awal
while jawab == 'Y':

  # Berikan ke-3 koefien persamaan kuadrat
  koefA = raw_input('\nKoefisien A = ')
  koefA = float(koefA)
  koefB = raw_input('Koefisien B = ')
  koefB = float(koefB)
  koefC = raw_input('Koefisien C = ')
  koefC = float(koefC)
  print '\nKoefisien persamaan kuadrat:', koefA, koefB, koefC

  # Hitung dan tampilkan diskriminan
  diskri = nilaiDiskriminan(koefA, koefB, koefC)
  print '    Diskriminan adalah %.2f' % (diskri)

  # Periksa diskriminan dan tentukan akar
  if diskri > 0:
    print '    Kasus 1: akar yg real dan berbeda'
    akar1, akar2 = akarBerbeda(koefA, koefB, diskri)
  elif diskri == 0:
    print '    Kasus 2: akar yg real dan kembar'
    akar1, akar2 = akarKembar(koefA, koefB)
  else:
    print '    Kasus 3: akar yang kompleks'
    akar1, akar2 = akarKompleks(koefA, koefB, diskri)

  # Tampilkan akar hasil perhitungan
  print '\nAkar persamaan kuadrat:'
  print '    x1 =', akar1 
  print '    x2 =', akar2

  # Uji apakah akan mengulang program
  jawab = raw_input('\nUlangi (Y/T)?: ')
