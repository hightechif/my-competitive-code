# bacaBerkas.py : Program Python untuk membuka dan membaca
#                 data suhu lingkungan dalam suatu bulan.
# Agus Arif, 05-10-2015

# Buka berkas
namaBerkas = 'suhu_juni.txt'
berkas = open(namaBerkas, mode = 'r')

# Baca baris-baris data dari berkas
jumlah = 0
cacah = 0
for i in berkas:
  data = int(i)
  jumlah += data
  cacah += 1
  print cacah, data, jumlah

# Tutup berkas
berkas.close()

# Hitung rerata suhu dalam 1 bulan
rerataSuhu = float(jumlah) / cacah
print '\nSuhu rerata = %.2f' % (rerataSuhu)
