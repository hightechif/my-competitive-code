# ujiContinue.py: Program Python sederhana untuk menguji pemakaian
#                 pernyataan 'continue'.
# Agus Arif, 28-09-2015

print 'Berikan username dan password yang absah.\n'
while True:
  username = raw_input('username: ')
  if username != 'ali':
    continue
  print '  Hai Ali!'
  print '  Berikan password anda (jenis ikan).'
  password = raw_input('password: ')
  if password == 'hiu':
    break
  else:
    print

print '\nAkses diberikan kepada Ali.'
