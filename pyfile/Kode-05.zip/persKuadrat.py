# persKuadrat.py: Program Python yang secara berulang-kali
#                 menentukan dua akar persamaan kuadrat se-
#                 telah 3 koefisiennya dimasukkan melalui
#                 papan-ketik.
# Agus Arif dkk, 23-09-2015

# Tampilkan judul program
print ' Penentuan Akar Persamaan Kuadrat'
print 'Dengan Diketahui Tiga Koefisiennya'
print '~' * 34

# Ulangi kalang penentuan akar persamaan kuadrat
jawab = 'Y'
while jawab == 'Y':
  
  # Berikan ke-3 koefien persamaan kuadrat
  A = raw_input('\nKoefisien A = ')
  A = float(A)
  B = raw_input('Koefisien B = ')
  B = float(B)
  C = raw_input('Koefisien C = ')
  C = float(C)
  print '\nKoefisien persamaan kuadrat:', A, B, C

  # Hitung diskriminan
  D = B ** 2 - 4 * A * C
  print '    Diskriminan adalah %.2f' % (D)

  # Periksa diskriminan dan tentukan akar
  if D > 0:
    print '    Kasus 1: akar yg real dan berbeda'
    x1 = (-B + D**0.5) / (2 * A)
    x2 = (-B - D**0.5) / (2 * A)
  elif D == 0:
    print '    Kasus 2: akar yg real dan kembar'
    x1 = -B / (2 * A)
    x2 = x1
  else:
    print '    Kasus 3: akar yang kompleks'
    x1 = -B / (2 * A) + 1j * (abs(D)**0.5) / (2 * A)
    x2 = -B / (2 * A) - 1j * (abs(D)**0.5) / (2 * A)

  # Tampilkan akar hasil perhitungan
  print '\nAkar persamaan kuadrat:'
  print '    x1 =', x1 
  print '    x2 =', x2

  # Uji apakah akan mengulang program
  jawab = raw_input('\nUlangi (Y/T)?: ')
