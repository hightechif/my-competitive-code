# ujiBreak.py: Program Python sederhana untuk menguji pemakaian
#              pernyataan 'break'.
# Agus Arif, 28-09-2015

while True:
  nama = raw_input('Berikan nama anda: ')
  if nama == 'Ali':
    break
  else:
    print '  Nama yang salah!\n'

print '\nTerima kasih, Ali.'
