# halo1.py : Program Python yang menyampaikan pesan 'Halo Dunia!' dan
#            menanyakan nama pengguna program (versi 1).
# Agus Arif, 07-09-2015

print 'Halo Dunia!'
print 'Beritahukan nama anda: '         # menanyakan nama pengguna
namaMu = raw_input()
print 'Senang berkenalan dengan anda, ' + namaMu

print 'Panjang nama anda adalah '
print len(namaMu)                       # fungsi len() = panjang string

print 'Berapa umur anda? '
usiaMu = raw_input()
print 'Anda akan berusia ' + str(int(usiaMu) + 1) + ' pada tahun depan.'
# Konversi menjadi bilangan bulat dengan fungsi int()
# Konversi menjadi string dengan fungsi str()
