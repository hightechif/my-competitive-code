# konversi.py : Program Python yang mengubah satu suhu dari derC menjadi
#               derF, derR dan K.
# Agus Arif, 07-09-2015

# Tampilkan judul program
print '   Program Konversi Satuan Suhu'
print 'dari derC menjadi derF, derR dan K'
print '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n'

# Masukkan nilai suhu dalam derC
suhuC = raw_input('Masukkan nilai suhu (dalam derC): ')
suhuC = float(suhuC)          # ubah tipe str menjadi float

# Konversi dari derajat Celsius menjadi satuan suhu lainnya
suhuF = 9.0/5 * suhuC + 32.0  # menjadi derajat Fahrenheit
suhuR = 4.0/5 * suhuC         # menjadi derajat Reamur
suhuK = suhuC + 273.15        # menjadi Kelvin
                        
# Tampilkan hasil perhitungan
print '\nSuhu bernilai ' + str(suhuC) + ' derajat Celsius'
print 'setara dengan ' + str(suhuF) + ' derajat Fahrenheit'
print '              ' + str(suhuR) + ' derajat Reamur'
print '              ' + str(suhuK) + ' Kelvin'
