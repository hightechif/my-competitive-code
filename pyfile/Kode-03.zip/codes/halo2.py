# halo2.py : Program Python yang menyampaikan pesan 'Halo Dunia!' dan
#            menanyakan nama pengguna program (versi 2).
# Agus Arif, 07-09-2015

print 'Halo Dunia!\n'

# Fungsi raw_input(argumen) = fungsi print(argumen) + raw_input()
namaMu = raw_input('Beritahukan nama anda: ') 
print 'Senang berkenalan dengan anda, ' + namaMu + '.'

# Output fungsi len() harus dikonversi menjadi string sebelum digabung
print 'Panjang nama anda adalah ' + str(len(namaMu)) + ' karakter.\n'
                        
# Fungsi raw_input(argumen) = fungsi print(argumen) + raw_input()
usiaMu = raw_input('Berapa umur anda? ')
print 'Anda akan berusia ' + str(int(usiaMu) + 1) + ' pada tahun depan.'
